﻿namespace AnthonyRedamontiHomework2Question2
{
    partial class Mars
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.reg0TextBox = new System.Windows.Forms.TextBox();
            this.reg1TextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.reg2TextBox = new System.Windows.Forms.TextBox();
            this.reg3TextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.reg4TextBox = new System.Windows.Forms.TextBox();
            this.reg5TextBox = new System.Windows.Forms.TextBox();
            this.reg6TextBox = new System.Windows.Forms.TextBox();
            this.reg7TextBox = new System.Windows.Forms.TextBox();
            this.reg8TextBox = new System.Windows.Forms.TextBox();
            this.reg9TextBox = new System.Windows.Forms.TextBox();
            this.reg10TextBox = new System.Windows.Forms.TextBox();
            this.reg11TextBox = new System.Windows.Forms.TextBox();
            this.reg12TextBox = new System.Windows.Forms.TextBox();
            this.reg13TextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.reg14TextBox = new System.Windows.Forms.TextBox();
            this.reg15TextBox = new System.Windows.Forms.TextBox();
            this.reg16TextBox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.reg31TextBox = new System.Windows.Forms.TextBox();
            this.reg30TextBox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.reg29TextBox = new System.Windows.Forms.TextBox();
            this.reg28TextBox = new System.Windows.Forms.TextBox();
            this.reg27TextBox = new System.Windows.Forms.TextBox();
            this.reg26TextBox = new System.Windows.Forms.TextBox();
            this.reg25TextBox = new System.Windows.Forms.TextBox();
            this.reg24TextBox = new System.Windows.Forms.TextBox();
            this.reg23TextBox = new System.Windows.Forms.TextBox();
            this.reg22TextBox = new System.Windows.Forms.TextBox();
            this.reg21TextBox = new System.Windows.Forms.TextBox();
            this.reg20TextBox = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.reg19TextBox = new System.Windows.Forms.TextBox();
            this.reg18TextBox = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.reg17TextBox = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.memoryTextBox0 = new System.Windows.Forms.TextBox();
            this.memoryTextBox1 = new System.Windows.Forms.TextBox();
            this.memoryTextBox3 = new System.Windows.Forms.TextBox();
            this.memoryTextBox2 = new System.Windows.Forms.TextBox();
            this.memoryTextBox7 = new System.Windows.Forms.TextBox();
            this.memoryTextBox6 = new System.Windows.Forms.TextBox();
            this.memoryTextBox5 = new System.Windows.Forms.TextBox();
            this.memoryTextBox4 = new System.Windows.Forms.TextBox();
            this.memoryTextBox15 = new System.Windows.Forms.TextBox();
            this.memoryTextBox14 = new System.Windows.Forms.TextBox();
            this.memoryTextBox13 = new System.Windows.Forms.TextBox();
            this.memoryTextBox12 = new System.Windows.Forms.TextBox();
            this.memoryTextBox11 = new System.Windows.Forms.TextBox();
            this.memoryTextBox10 = new System.Windows.Forms.TextBox();
            this.memoryTextBox9 = new System.Windows.Forms.TextBox();
            this.memoryTextBox8 = new System.Windows.Forms.TextBox();
            this.memoryTextBox23 = new System.Windows.Forms.TextBox();
            this.memoryTextBox22 = new System.Windows.Forms.TextBox();
            this.memoryTextBox21 = new System.Windows.Forms.TextBox();
            this.memoryTextBox20 = new System.Windows.Forms.TextBox();
            this.memoryTextBox19 = new System.Windows.Forms.TextBox();
            this.memoryTextBox18 = new System.Windows.Forms.TextBox();
            this.memoryTextBox17 = new System.Windows.Forms.TextBox();
            this.memoryTextBox16 = new System.Windows.Forms.TextBox();
            this.memoryTextBox31 = new System.Windows.Forms.TextBox();
            this.memoryTextBox30 = new System.Windows.Forms.TextBox();
            this.memoryTextBox29 = new System.Windows.Forms.TextBox();
            this.memoryTextBox28 = new System.Windows.Forms.TextBox();
            this.memoryTextBox27 = new System.Windows.Forms.TextBox();
            this.memoryTextBox26 = new System.Windows.Forms.TextBox();
            this.memoryTextBox25 = new System.Windows.Forms.TextBox();
            this.memoryTextBox24 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.scriptTextBox = new System.Windows.Forms.TextBox();
            this.translationTextBox = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.singleStepButton = new System.Windows.Forms.Button();
            this.playButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // reg0TextBox
            // 
            this.reg0TextBox.Location = new System.Drawing.Point(649, 60);
            this.reg0TextBox.Name = "reg0TextBox";
            this.reg0TextBox.ReadOnly = true;
            this.reg0TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg0TextBox.TabIndex = 0;
            // 
            // reg1TextBox
            // 
            this.reg1TextBox.Location = new System.Drawing.Point(649, 82);
            this.reg1TextBox.Name = "reg1TextBox";
            this.reg1TextBox.ReadOnly = true;
            this.reg1TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg1TextBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(598, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "0) $zero";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(598, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "1) $at";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(598, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "2) $v0";
            // 
            // reg2TextBox
            // 
            this.reg2TextBox.Location = new System.Drawing.Point(649, 104);
            this.reg2TextBox.Name = "reg2TextBox";
            this.reg2TextBox.ReadOnly = true;
            this.reg2TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg2TextBox.TabIndex = 5;
            // 
            // reg3TextBox
            // 
            this.reg3TextBox.Location = new System.Drawing.Point(649, 126);
            this.reg3TextBox.Name = "reg3TextBox";
            this.reg3TextBox.ReadOnly = true;
            this.reg3TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg3TextBox.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(598, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "3) $v1";
            // 
            // reg4TextBox
            // 
            this.reg4TextBox.Location = new System.Drawing.Point(649, 148);
            this.reg4TextBox.Name = "reg4TextBox";
            this.reg4TextBox.ReadOnly = true;
            this.reg4TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg4TextBox.TabIndex = 8;
            // 
            // reg5TextBox
            // 
            this.reg5TextBox.Location = new System.Drawing.Point(649, 170);
            this.reg5TextBox.Name = "reg5TextBox";
            this.reg5TextBox.ReadOnly = true;
            this.reg5TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg5TextBox.TabIndex = 9;
            // 
            // reg6TextBox
            // 
            this.reg6TextBox.Location = new System.Drawing.Point(649, 192);
            this.reg6TextBox.Name = "reg6TextBox";
            this.reg6TextBox.ReadOnly = true;
            this.reg6TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg6TextBox.TabIndex = 10;
            // 
            // reg7TextBox
            // 
            this.reg7TextBox.Location = new System.Drawing.Point(649, 214);
            this.reg7TextBox.Name = "reg7TextBox";
            this.reg7TextBox.ReadOnly = true;
            this.reg7TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg7TextBox.TabIndex = 11;
            // 
            // reg8TextBox
            // 
            this.reg8TextBox.Location = new System.Drawing.Point(649, 236);
            this.reg8TextBox.Name = "reg8TextBox";
            this.reg8TextBox.ReadOnly = true;
            this.reg8TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg8TextBox.TabIndex = 12;
            // 
            // reg9TextBox
            // 
            this.reg9TextBox.Location = new System.Drawing.Point(649, 258);
            this.reg9TextBox.Name = "reg9TextBox";
            this.reg9TextBox.ReadOnly = true;
            this.reg9TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg9TextBox.TabIndex = 13;
            // 
            // reg10TextBox
            // 
            this.reg10TextBox.Location = new System.Drawing.Point(649, 280);
            this.reg10TextBox.Name = "reg10TextBox";
            this.reg10TextBox.ReadOnly = true;
            this.reg10TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg10TextBox.TabIndex = 14;
            // 
            // reg11TextBox
            // 
            this.reg11TextBox.Location = new System.Drawing.Point(649, 302);
            this.reg11TextBox.Name = "reg11TextBox";
            this.reg11TextBox.ReadOnly = true;
            this.reg11TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg11TextBox.TabIndex = 15;
            // 
            // reg12TextBox
            // 
            this.reg12TextBox.Location = new System.Drawing.Point(649, 324);
            this.reg12TextBox.Name = "reg12TextBox";
            this.reg12TextBox.ReadOnly = true;
            this.reg12TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg12TextBox.TabIndex = 16;
            // 
            // reg13TextBox
            // 
            this.reg13TextBox.Location = new System.Drawing.Point(649, 346);
            this.reg13TextBox.Name = "reg13TextBox";
            this.reg13TextBox.ReadOnly = true;
            this.reg13TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg13TextBox.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(598, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "4) $a0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(598, 173);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "5) $a1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(598, 195);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "6) $a2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(598, 217);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "7) $a3";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(598, 239);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 13);
            this.label9.TabIndex = 22;
            this.label9.Text = "8) $t0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(598, 261);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 13);
            this.label10.TabIndex = 23;
            this.label10.Text = "9) $t1";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(598, 283);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "10) $t2";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(598, 305);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "11) $t3";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(598, 327);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 13);
            this.label13.TabIndex = 26;
            this.label13.Text = "12) $t4";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(598, 349);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 13);
            this.label14.TabIndex = 27;
            this.label14.Text = "13) $t5";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(598, 371);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(40, 13);
            this.label15.TabIndex = 28;
            this.label15.Text = "14) $f0";
            // 
            // reg14TextBox
            // 
            this.reg14TextBox.Location = new System.Drawing.Point(649, 368);
            this.reg14TextBox.Name = "reg14TextBox";
            this.reg14TextBox.ReadOnly = true;
            this.reg14TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg14TextBox.TabIndex = 29;
            // 
            // reg15TextBox
            // 
            this.reg15TextBox.Location = new System.Drawing.Point(649, 390);
            this.reg15TextBox.Name = "reg15TextBox";
            this.reg15TextBox.ReadOnly = true;
            this.reg15TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg15TextBox.TabIndex = 30;
            // 
            // reg16TextBox
            // 
            this.reg16TextBox.Location = new System.Drawing.Point(826, 60);
            this.reg16TextBox.Name = "reg16TextBox";
            this.reg16TextBox.ReadOnly = true;
            this.reg16TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg16TextBox.TabIndex = 31;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(598, 393);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 13);
            this.label16.TabIndex = 32;
            this.label16.Text = "15) $f1";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(775, 63);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(42, 13);
            this.label17.TabIndex = 33;
            this.label17.Text = "16) $s0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(775, 393);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(40, 13);
            this.label18.TabIndex = 63;
            this.label18.Text = "31) $ra";
            // 
            // reg31TextBox
            // 
            this.reg31TextBox.Location = new System.Drawing.Point(826, 390);
            this.reg31TextBox.Name = "reg31TextBox";
            this.reg31TextBox.ReadOnly = true;
            this.reg31TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg31TextBox.TabIndex = 62;
            // 
            // reg30TextBox
            // 
            this.reg30TextBox.Location = new System.Drawing.Point(826, 368);
            this.reg30TextBox.Name = "reg30TextBox";
            this.reg30TextBox.ReadOnly = true;
            this.reg30TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg30TextBox.TabIndex = 61;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(775, 371);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(40, 13);
            this.label19.TabIndex = 60;
            this.label19.Text = "30) $fp";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(775, 349);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(42, 13);
            this.label20.TabIndex = 59;
            this.label20.Text = "29) $sp";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(775, 327);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(43, 13);
            this.label21.TabIndex = 58;
            this.label21.Text = "28) $gp";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(775, 305);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(43, 13);
            this.label22.TabIndex = 57;
            this.label22.Text = "27) $k1";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(775, 283);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(43, 13);
            this.label23.TabIndex = 56;
            this.label23.Text = "26) $k0";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(775, 261);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(40, 13);
            this.label24.TabIndex = 55;
            this.label24.Text = "25) $f5";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(775, 239);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(40, 13);
            this.label25.TabIndex = 54;
            this.label25.Text = "24) $f4";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(775, 217);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(40, 13);
            this.label26.TabIndex = 53;
            this.label26.Text = "23) $f3";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(775, 195);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(40, 13);
            this.label27.TabIndex = 52;
            this.label27.Text = "22) $f2";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(775, 173);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(42, 13);
            this.label28.TabIndex = 51;
            this.label28.Text = "21) $s5";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(775, 151);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(42, 13);
            this.label29.TabIndex = 50;
            this.label29.Text = "20) $s4";
            // 
            // reg29TextBox
            // 
            this.reg29TextBox.Location = new System.Drawing.Point(826, 346);
            this.reg29TextBox.Name = "reg29TextBox";
            this.reg29TextBox.ReadOnly = true;
            this.reg29TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg29TextBox.TabIndex = 49;
            // 
            // reg28TextBox
            // 
            this.reg28TextBox.Location = new System.Drawing.Point(826, 324);
            this.reg28TextBox.Name = "reg28TextBox";
            this.reg28TextBox.ReadOnly = true;
            this.reg28TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg28TextBox.TabIndex = 48;
            // 
            // reg27TextBox
            // 
            this.reg27TextBox.Location = new System.Drawing.Point(826, 302);
            this.reg27TextBox.Name = "reg27TextBox";
            this.reg27TextBox.ReadOnly = true;
            this.reg27TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg27TextBox.TabIndex = 47;
            // 
            // reg26TextBox
            // 
            this.reg26TextBox.Location = new System.Drawing.Point(826, 280);
            this.reg26TextBox.Name = "reg26TextBox";
            this.reg26TextBox.ReadOnly = true;
            this.reg26TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg26TextBox.TabIndex = 46;
            // 
            // reg25TextBox
            // 
            this.reg25TextBox.Location = new System.Drawing.Point(826, 258);
            this.reg25TextBox.Name = "reg25TextBox";
            this.reg25TextBox.ReadOnly = true;
            this.reg25TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg25TextBox.TabIndex = 45;
            // 
            // reg24TextBox
            // 
            this.reg24TextBox.Location = new System.Drawing.Point(826, 236);
            this.reg24TextBox.Name = "reg24TextBox";
            this.reg24TextBox.ReadOnly = true;
            this.reg24TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg24TextBox.TabIndex = 44;
            // 
            // reg23TextBox
            // 
            this.reg23TextBox.Location = new System.Drawing.Point(826, 214);
            this.reg23TextBox.Name = "reg23TextBox";
            this.reg23TextBox.ReadOnly = true;
            this.reg23TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg23TextBox.TabIndex = 43;
            // 
            // reg22TextBox
            // 
            this.reg22TextBox.Location = new System.Drawing.Point(826, 192);
            this.reg22TextBox.Name = "reg22TextBox";
            this.reg22TextBox.ReadOnly = true;
            this.reg22TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg22TextBox.TabIndex = 42;
            // 
            // reg21TextBox
            // 
            this.reg21TextBox.Location = new System.Drawing.Point(826, 170);
            this.reg21TextBox.Name = "reg21TextBox";
            this.reg21TextBox.ReadOnly = true;
            this.reg21TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg21TextBox.TabIndex = 41;
            // 
            // reg20TextBox
            // 
            this.reg20TextBox.Location = new System.Drawing.Point(826, 148);
            this.reg20TextBox.Name = "reg20TextBox";
            this.reg20TextBox.ReadOnly = true;
            this.reg20TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg20TextBox.TabIndex = 40;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(775, 129);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(42, 13);
            this.label30.TabIndex = 39;
            this.label30.Text = "19) $s3";
            // 
            // reg19TextBox
            // 
            this.reg19TextBox.Location = new System.Drawing.Point(826, 126);
            this.reg19TextBox.Name = "reg19TextBox";
            this.reg19TextBox.ReadOnly = true;
            this.reg19TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg19TextBox.TabIndex = 38;
            // 
            // reg18TextBox
            // 
            this.reg18TextBox.Location = new System.Drawing.Point(826, 104);
            this.reg18TextBox.Name = "reg18TextBox";
            this.reg18TextBox.ReadOnly = true;
            this.reg18TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg18TextBox.TabIndex = 37;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(775, 107);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(42, 13);
            this.label31.TabIndex = 36;
            this.label31.Text = "18) $s2";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(775, 85);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(42, 13);
            this.label32.TabIndex = 35;
            this.label32.Text = "17) $s1";
            // 
            // reg17TextBox
            // 
            this.reg17TextBox.Location = new System.Drawing.Point(826, 82);
            this.reg17TextBox.Name = "reg17TextBox";
            this.reg17TextBox.ReadOnly = true;
            this.reg17TextBox.Size = new System.Drawing.Size(100, 20);
            this.reg17TextBox.TabIndex = 34;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(732, 18);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(86, 20);
            this.label33.TabIndex = 64;
            this.label33.Text = "Registers";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // memoryTextBox0
            // 
            this.memoryTextBox0.Location = new System.Drawing.Point(119, 482);
            this.memoryTextBox0.Name = "memoryTextBox0";
            this.memoryTextBox0.ReadOnly = true;
            this.memoryTextBox0.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox0.TabIndex = 65;
            // 
            // memoryTextBox1
            // 
            this.memoryTextBox1.Location = new System.Drawing.Point(220, 482);
            this.memoryTextBox1.Name = "memoryTextBox1";
            this.memoryTextBox1.ReadOnly = true;
            this.memoryTextBox1.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox1.TabIndex = 66;
            // 
            // memoryTextBox3
            // 
            this.memoryTextBox3.Location = new System.Drawing.Point(422, 482);
            this.memoryTextBox3.Name = "memoryTextBox3";
            this.memoryTextBox3.ReadOnly = true;
            this.memoryTextBox3.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox3.TabIndex = 68;
            // 
            // memoryTextBox2
            // 
            this.memoryTextBox2.Location = new System.Drawing.Point(321, 482);
            this.memoryTextBox2.Name = "memoryTextBox2";
            this.memoryTextBox2.ReadOnly = true;
            this.memoryTextBox2.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox2.TabIndex = 67;
            // 
            // memoryTextBox7
            // 
            this.memoryTextBox7.Location = new System.Drawing.Point(826, 482);
            this.memoryTextBox7.Name = "memoryTextBox7";
            this.memoryTextBox7.ReadOnly = true;
            this.memoryTextBox7.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox7.TabIndex = 72;
            // 
            // memoryTextBox6
            // 
            this.memoryTextBox6.Location = new System.Drawing.Point(725, 482);
            this.memoryTextBox6.Name = "memoryTextBox6";
            this.memoryTextBox6.ReadOnly = true;
            this.memoryTextBox6.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox6.TabIndex = 71;
            // 
            // memoryTextBox5
            // 
            this.memoryTextBox5.Location = new System.Drawing.Point(624, 482);
            this.memoryTextBox5.Name = "memoryTextBox5";
            this.memoryTextBox5.ReadOnly = true;
            this.memoryTextBox5.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox5.TabIndex = 70;
            // 
            // memoryTextBox4
            // 
            this.memoryTextBox4.Location = new System.Drawing.Point(523, 482);
            this.memoryTextBox4.Name = "memoryTextBox4";
            this.memoryTextBox4.ReadOnly = true;
            this.memoryTextBox4.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox4.TabIndex = 69;
            // 
            // memoryTextBox15
            // 
            this.memoryTextBox15.Location = new System.Drawing.Point(826, 503);
            this.memoryTextBox15.Name = "memoryTextBox15";
            this.memoryTextBox15.ReadOnly = true;
            this.memoryTextBox15.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox15.TabIndex = 80;
            // 
            // memoryTextBox14
            // 
            this.memoryTextBox14.Location = new System.Drawing.Point(725, 503);
            this.memoryTextBox14.Name = "memoryTextBox14";
            this.memoryTextBox14.ReadOnly = true;
            this.memoryTextBox14.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox14.TabIndex = 79;
            // 
            // memoryTextBox13
            // 
            this.memoryTextBox13.Location = new System.Drawing.Point(624, 503);
            this.memoryTextBox13.Name = "memoryTextBox13";
            this.memoryTextBox13.ReadOnly = true;
            this.memoryTextBox13.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox13.TabIndex = 78;
            // 
            // memoryTextBox12
            // 
            this.memoryTextBox12.Location = new System.Drawing.Point(523, 503);
            this.memoryTextBox12.Name = "memoryTextBox12";
            this.memoryTextBox12.ReadOnly = true;
            this.memoryTextBox12.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox12.TabIndex = 77;
            // 
            // memoryTextBox11
            // 
            this.memoryTextBox11.Location = new System.Drawing.Point(422, 503);
            this.memoryTextBox11.Name = "memoryTextBox11";
            this.memoryTextBox11.ReadOnly = true;
            this.memoryTextBox11.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox11.TabIndex = 76;
            // 
            // memoryTextBox10
            // 
            this.memoryTextBox10.Location = new System.Drawing.Point(321, 503);
            this.memoryTextBox10.Name = "memoryTextBox10";
            this.memoryTextBox10.ReadOnly = true;
            this.memoryTextBox10.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox10.TabIndex = 75;
            // 
            // memoryTextBox9
            // 
            this.memoryTextBox9.Location = new System.Drawing.Point(220, 503);
            this.memoryTextBox9.Name = "memoryTextBox9";
            this.memoryTextBox9.ReadOnly = true;
            this.memoryTextBox9.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox9.TabIndex = 74;
            // 
            // memoryTextBox8
            // 
            this.memoryTextBox8.Location = new System.Drawing.Point(119, 503);
            this.memoryTextBox8.Name = "memoryTextBox8";
            this.memoryTextBox8.ReadOnly = true;
            this.memoryTextBox8.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox8.TabIndex = 73;
            // 
            // memoryTextBox23
            // 
            this.memoryTextBox23.Location = new System.Drawing.Point(826, 524);
            this.memoryTextBox23.Name = "memoryTextBox23";
            this.memoryTextBox23.ReadOnly = true;
            this.memoryTextBox23.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox23.TabIndex = 88;
            // 
            // memoryTextBox22
            // 
            this.memoryTextBox22.Location = new System.Drawing.Point(725, 524);
            this.memoryTextBox22.Name = "memoryTextBox22";
            this.memoryTextBox22.ReadOnly = true;
            this.memoryTextBox22.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox22.TabIndex = 87;
            // 
            // memoryTextBox21
            // 
            this.memoryTextBox21.Location = new System.Drawing.Point(624, 524);
            this.memoryTextBox21.Name = "memoryTextBox21";
            this.memoryTextBox21.ReadOnly = true;
            this.memoryTextBox21.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox21.TabIndex = 86;
            // 
            // memoryTextBox20
            // 
            this.memoryTextBox20.Location = new System.Drawing.Point(523, 524);
            this.memoryTextBox20.Name = "memoryTextBox20";
            this.memoryTextBox20.ReadOnly = true;
            this.memoryTextBox20.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox20.TabIndex = 85;
            // 
            // memoryTextBox19
            // 
            this.memoryTextBox19.Location = new System.Drawing.Point(422, 524);
            this.memoryTextBox19.Name = "memoryTextBox19";
            this.memoryTextBox19.ReadOnly = true;
            this.memoryTextBox19.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox19.TabIndex = 84;
            // 
            // memoryTextBox18
            // 
            this.memoryTextBox18.Location = new System.Drawing.Point(321, 524);
            this.memoryTextBox18.Name = "memoryTextBox18";
            this.memoryTextBox18.ReadOnly = true;
            this.memoryTextBox18.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox18.TabIndex = 83;
            // 
            // memoryTextBox17
            // 
            this.memoryTextBox17.Location = new System.Drawing.Point(220, 524);
            this.memoryTextBox17.Name = "memoryTextBox17";
            this.memoryTextBox17.ReadOnly = true;
            this.memoryTextBox17.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox17.TabIndex = 82;
            // 
            // memoryTextBox16
            // 
            this.memoryTextBox16.Location = new System.Drawing.Point(119, 524);
            this.memoryTextBox16.Name = "memoryTextBox16";
            this.memoryTextBox16.ReadOnly = true;
            this.memoryTextBox16.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox16.TabIndex = 81;
            // 
            // memoryTextBox31
            // 
            this.memoryTextBox31.Location = new System.Drawing.Point(826, 545);
            this.memoryTextBox31.Name = "memoryTextBox31";
            this.memoryTextBox31.ReadOnly = true;
            this.memoryTextBox31.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox31.TabIndex = 96;
            // 
            // memoryTextBox30
            // 
            this.memoryTextBox30.Location = new System.Drawing.Point(725, 545);
            this.memoryTextBox30.Name = "memoryTextBox30";
            this.memoryTextBox30.ReadOnly = true;
            this.memoryTextBox30.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox30.TabIndex = 95;
            // 
            // memoryTextBox29
            // 
            this.memoryTextBox29.Location = new System.Drawing.Point(624, 545);
            this.memoryTextBox29.Name = "memoryTextBox29";
            this.memoryTextBox29.ReadOnly = true;
            this.memoryTextBox29.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox29.TabIndex = 94;
            // 
            // memoryTextBox28
            // 
            this.memoryTextBox28.Location = new System.Drawing.Point(523, 545);
            this.memoryTextBox28.Name = "memoryTextBox28";
            this.memoryTextBox28.ReadOnly = true;
            this.memoryTextBox28.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox28.TabIndex = 93;
            // 
            // memoryTextBox27
            // 
            this.memoryTextBox27.Location = new System.Drawing.Point(422, 545);
            this.memoryTextBox27.Name = "memoryTextBox27";
            this.memoryTextBox27.ReadOnly = true;
            this.memoryTextBox27.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox27.TabIndex = 92;
            // 
            // memoryTextBox26
            // 
            this.memoryTextBox26.Location = new System.Drawing.Point(321, 545);
            this.memoryTextBox26.Name = "memoryTextBox26";
            this.memoryTextBox26.ReadOnly = true;
            this.memoryTextBox26.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox26.TabIndex = 91;
            // 
            // memoryTextBox25
            // 
            this.memoryTextBox25.Location = new System.Drawing.Point(220, 545);
            this.memoryTextBox25.Name = "memoryTextBox25";
            this.memoryTextBox25.ReadOnly = true;
            this.memoryTextBox25.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox25.TabIndex = 90;
            // 
            // memoryTextBox24
            // 
            this.memoryTextBox24.Location = new System.Drawing.Point(119, 545);
            this.memoryTextBox24.Name = "memoryTextBox24";
            this.memoryTextBox24.ReadOnly = true;
            this.memoryTextBox24.Size = new System.Drawing.Size(100, 20);
            this.memoryTextBox24.TabIndex = 89;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(447, 440);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(125, 20);
            this.label34.TabIndex = 97;
            this.label34.Text = "Data Segment";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(52, 485);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(61, 13);
            this.label35.TabIndex = 98;
            this.label35.Text = "268500992";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(140, 466);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(55, 13);
            this.label36.TabIndex = 99;
            this.label36.Text = "Value (+0)";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(246, 466);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(55, 13);
            this.label37.TabIndex = 100;
            this.label37.Text = "Value (+4)";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(343, 466);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(55, 13);
            this.label38.TabIndex = 101;
            this.label38.Text = "Value (+8)";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(448, 466);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(61, 13);
            this.label39.TabIndex = 102;
            this.label39.Text = "Value (+12)";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(545, 466);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(61, 13);
            this.label40.TabIndex = 103;
            this.label40.Text = "Value (+16)";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(644, 466);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(61, 13);
            this.label41.TabIndex = 104;
            this.label41.Text = "Value (+20)";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(745, 466);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(61, 13);
            this.label42.TabIndex = 105;
            this.label42.Text = "Value (+24)";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(841, 466);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(61, 13);
            this.label43.TabIndex = 106;
            this.label43.Text = "Value (+28)";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(58, 466);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(45, 13);
            this.label44.TabIndex = 107;
            this.label44.Text = "Address";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(52, 506);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(61, 13);
            this.label45.TabIndex = 108;
            this.label45.Text = "268501024";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(52, 527);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(61, 13);
            this.label48.TabIndex = 111;
            this.label48.Text = "268501056";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(52, 548);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(61, 13);
            this.label46.TabIndex = 112;
            this.label46.Text = "268501088";
            // 
            // scriptTextBox
            // 
            this.scriptTextBox.Location = new System.Drawing.Point(15, 27);
            this.scriptTextBox.Multiline = true;
            this.scriptTextBox.Name = "scriptTextBox";
            this.scriptTextBox.Size = new System.Drawing.Size(191, 321);
            this.scriptTextBox.TabIndex = 113;
            // 
            // translationTextBox
            // 
            this.translationTextBox.Location = new System.Drawing.Point(209, 27);
            this.translationTextBox.Multiline = true;
            this.translationTextBox.Name = "translationTextBox";
            this.translationTextBox.ReadOnly = true;
            this.translationTextBox.Size = new System.Drawing.Size(371, 321);
            this.translationTextBox.TabIndex = 122;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(18, 11);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(114, 13);
            this.label49.TabIndex = 123;
            this.label49.Text = "Type Instructions Here";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(206, 11);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(59, 13);
            this.label50.TabIndex = 124;
            this.label50.Text = "Translation";
            // 
            // singleStepButton
            // 
            this.singleStepButton.BackgroundImage = global::AnthonyRedamontiHomework2Question2.Properties.Resources.singlestep;
            this.singleStepButton.Location = new System.Drawing.Point(113, 354);
            this.singleStepButton.Margin = new System.Windows.Forms.Padding(2);
            this.singleStepButton.Name = "singleStepButton";
            this.singleStepButton.Size = new System.Drawing.Size(93, 94);
            this.singleStepButton.TabIndex = 126;
            this.singleStepButton.UseVisualStyleBackColor = true;
            this.singleStepButton.Click += new System.EventHandler(this.singleStepButton_Click);
            // 
            // playButton
            // 
            this.playButton.Image = global::AnthonyRedamontiHomework2Question2.Properties.Resources.playButton2;
            this.playButton.Location = new System.Drawing.Point(15, 354);
            this.playButton.Name = "playButton";
            this.playButton.Size = new System.Drawing.Size(93, 94);
            this.playButton.TabIndex = 114;
            this.playButton.UseVisualStyleBackColor = true;
            this.playButton.Click += new System.EventHandler(this.playButton_Click);
            // 
            // Mars
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(948, 572);
            this.Controls.Add(this.singleStepButton);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.translationTextBox);
            this.Controls.Add(this.playButton);
            this.Controls.Add(this.scriptTextBox);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.memoryTextBox31);
            this.Controls.Add(this.memoryTextBox30);
            this.Controls.Add(this.memoryTextBox29);
            this.Controls.Add(this.memoryTextBox28);
            this.Controls.Add(this.memoryTextBox27);
            this.Controls.Add(this.memoryTextBox26);
            this.Controls.Add(this.memoryTextBox25);
            this.Controls.Add(this.memoryTextBox24);
            this.Controls.Add(this.memoryTextBox23);
            this.Controls.Add(this.memoryTextBox22);
            this.Controls.Add(this.memoryTextBox21);
            this.Controls.Add(this.memoryTextBox20);
            this.Controls.Add(this.memoryTextBox19);
            this.Controls.Add(this.memoryTextBox18);
            this.Controls.Add(this.memoryTextBox17);
            this.Controls.Add(this.memoryTextBox16);
            this.Controls.Add(this.memoryTextBox15);
            this.Controls.Add(this.memoryTextBox14);
            this.Controls.Add(this.memoryTextBox13);
            this.Controls.Add(this.memoryTextBox12);
            this.Controls.Add(this.memoryTextBox11);
            this.Controls.Add(this.memoryTextBox10);
            this.Controls.Add(this.memoryTextBox9);
            this.Controls.Add(this.memoryTextBox8);
            this.Controls.Add(this.memoryTextBox7);
            this.Controls.Add(this.memoryTextBox6);
            this.Controls.Add(this.memoryTextBox5);
            this.Controls.Add(this.memoryTextBox4);
            this.Controls.Add(this.memoryTextBox3);
            this.Controls.Add(this.memoryTextBox2);
            this.Controls.Add(this.memoryTextBox1);
            this.Controls.Add(this.memoryTextBox0);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.reg31TextBox);
            this.Controls.Add(this.reg30TextBox);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.reg29TextBox);
            this.Controls.Add(this.reg28TextBox);
            this.Controls.Add(this.reg27TextBox);
            this.Controls.Add(this.reg26TextBox);
            this.Controls.Add(this.reg25TextBox);
            this.Controls.Add(this.reg24TextBox);
            this.Controls.Add(this.reg23TextBox);
            this.Controls.Add(this.reg22TextBox);
            this.Controls.Add(this.reg21TextBox);
            this.Controls.Add(this.reg20TextBox);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.reg19TextBox);
            this.Controls.Add(this.reg18TextBox);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.reg17TextBox);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.reg16TextBox);
            this.Controls.Add(this.reg15TextBox);
            this.Controls.Add(this.reg14TextBox);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.reg13TextBox);
            this.Controls.Add(this.reg12TextBox);
            this.Controls.Add(this.reg11TextBox);
            this.Controls.Add(this.reg10TextBox);
            this.Controls.Add(this.reg9TextBox);
            this.Controls.Add(this.reg8TextBox);
            this.Controls.Add(this.reg7TextBox);
            this.Controls.Add(this.reg6TextBox);
            this.Controls.Add(this.reg5TextBox);
            this.Controls.Add(this.reg4TextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.reg3TextBox);
            this.Controls.Add(this.reg2TextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.reg1TextBox);
            this.Controls.Add(this.reg0TextBox);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Mars";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Mars_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox reg0TextBox;
        private System.Windows.Forms.TextBox reg1TextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox reg2TextBox;
        private System.Windows.Forms.TextBox reg3TextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox reg4TextBox;
        private System.Windows.Forms.TextBox reg5TextBox;
        private System.Windows.Forms.TextBox reg6TextBox;
        private System.Windows.Forms.TextBox reg7TextBox;
        private System.Windows.Forms.TextBox reg8TextBox;
        private System.Windows.Forms.TextBox reg9TextBox;
        private System.Windows.Forms.TextBox reg10TextBox;
        private System.Windows.Forms.TextBox reg11TextBox;
        private System.Windows.Forms.TextBox reg12TextBox;
        private System.Windows.Forms.TextBox reg13TextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox reg14TextBox;
        private System.Windows.Forms.TextBox reg15TextBox;
        private System.Windows.Forms.TextBox reg16TextBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox reg31TextBox;
        private System.Windows.Forms.TextBox reg30TextBox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox reg29TextBox;
        private System.Windows.Forms.TextBox reg28TextBox;
        private System.Windows.Forms.TextBox reg27TextBox;
        private System.Windows.Forms.TextBox reg26TextBox;
        private System.Windows.Forms.TextBox reg25TextBox;
        private System.Windows.Forms.TextBox reg24TextBox;
        private System.Windows.Forms.TextBox reg23TextBox;
        private System.Windows.Forms.TextBox reg22TextBox;
        private System.Windows.Forms.TextBox reg21TextBox;
        private System.Windows.Forms.TextBox reg20TextBox;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox reg19TextBox;
        private System.Windows.Forms.TextBox reg18TextBox;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox reg17TextBox;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox memoryTextBox0;
        private System.Windows.Forms.TextBox memoryTextBox1;
        private System.Windows.Forms.TextBox memoryTextBox3;
        private System.Windows.Forms.TextBox memoryTextBox2;
        private System.Windows.Forms.TextBox memoryTextBox7;
        private System.Windows.Forms.TextBox memoryTextBox6;
        private System.Windows.Forms.TextBox memoryTextBox5;
        private System.Windows.Forms.TextBox memoryTextBox4;
        private System.Windows.Forms.TextBox memoryTextBox15;
        private System.Windows.Forms.TextBox memoryTextBox14;
        private System.Windows.Forms.TextBox memoryTextBox13;
        private System.Windows.Forms.TextBox memoryTextBox12;
        private System.Windows.Forms.TextBox memoryTextBox11;
        private System.Windows.Forms.TextBox memoryTextBox10;
        private System.Windows.Forms.TextBox memoryTextBox9;
        private System.Windows.Forms.TextBox memoryTextBox8;
        private System.Windows.Forms.TextBox memoryTextBox23;
        private System.Windows.Forms.TextBox memoryTextBox22;
        private System.Windows.Forms.TextBox memoryTextBox21;
        private System.Windows.Forms.TextBox memoryTextBox20;
        private System.Windows.Forms.TextBox memoryTextBox19;
        private System.Windows.Forms.TextBox memoryTextBox18;
        private System.Windows.Forms.TextBox memoryTextBox17;
        private System.Windows.Forms.TextBox memoryTextBox16;
        private System.Windows.Forms.TextBox memoryTextBox31;
        private System.Windows.Forms.TextBox memoryTextBox30;
        private System.Windows.Forms.TextBox memoryTextBox29;
        private System.Windows.Forms.TextBox memoryTextBox28;
        private System.Windows.Forms.TextBox memoryTextBox27;
        private System.Windows.Forms.TextBox memoryTextBox26;
        private System.Windows.Forms.TextBox memoryTextBox25;
        private System.Windows.Forms.TextBox memoryTextBox24;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox scriptTextBox;
        private System.Windows.Forms.Button playButton;
        private System.Windows.Forms.TextBox translationTextBox;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Button singleStepButton;
    }
}

