///////////////////////////////////////////////////////////
//
// Anthony Redamonti
// 8-3-2021
//
// Source.cpp
// CIS554 Object Oriented Programming in C++
// Exercise 9_2 - Overriding Base Class Members
//
// The following code tests the base class "CommunityMember"
// and its derived class member functions.
//
///////////////////////////////////////////////////////////

#include "CommunityMember.h"
#include "Employee.h"
#include "Student.h"
#include <iostream>
using std::cout;
using std::endl;
using std::fixed; // used for displaying decimal of GPA

// Demonstrate CommunityMember class
void demonstrateCommunityMember(CommunityMember &communityMemberObj);

// Demonstrate Employee class
void demonstrateEmployee(Employee &employeeObj);

// Demonstrate Student class
void demonstrateStudent(Student &studentObj);

// print Syracuse Banner
void printSyracuseBanner();

int main()
{
	cout.precision(1); // 1 decimal place for GPA display

	// print Syracuse Banner
	printSyracuseBanner();

	// professional looking banner
	cout << "Anthony Redamonti\n" <<
		"Professor Jonathan S. Weissman\n" <<
		"CIS 554 - M401 Object Oriented Programming C++\n" <<
		"Syracuse University\n" <<
		"Exercise 9.1 - Simple Inheritance Test\n" <<
		"8/3/2021\n\n";

	// demonstrate CommunityMember default constructor
	cout << "***** Demonstrating the default constructor, and member methods, for class CommunityMember" << endl;
	CommunityMember commMember;
	demonstrateCommunityMember(commMember);
	cout << endl;

	// demonstrate CommunityMember initialization constructor
	cout << "***** Demonstrating the initialization constructor, and member methods, for class CommunityMember" << endl;
	CommunityMember commMemberHarry("Syracuse University", "Harry", "Potter", 1234);
	demonstrateCommunityMember(commMemberHarry);
	cout << endl;


	// demonstrate Employee default constructor
	cout << "***** Demonstrating the default constructor, and member methods, for class Employee" << endl;
	Employee commMemberEmp;
	demonstrateEmployee(commMemberEmp);
	cout << endl;


	// demonstrate Employee initialization constructor
	cout << "***** Demonstrating the initialization constructor, and member methods, for class Employee" << endl;
	Employee commMemberEmpHarry("Syracuse University", "Harry", "Potter", 1234, "Janitor", 25000);
	demonstrateEmployee(commMemberEmpHarry);
	cout << endl;

	// demonstrate Student initialization constructor
	cout << "***** Demonstrating the initialization constructor, and member methods, for class Student" << endl;
	Student commMemberEmpSally("Syracuse University", "Harry", "Potter", 1234, "History", 4.0);
	demonstrateStudent(commMemberEmpSally);
	cout << endl;
}

// function that displays the community member data using private data member functions
void demonstrateCommunityMember(CommunityMember & c)
{
	cout << c.getFirstName() << " "
		<< c.getLastName()
		<< " is a member of the " << c.getCommunityName() << " community, with member ID " << c.getMemberId() << endl;
}

// function that displays the employee member data as well as the community member data of the employee object.
void demonstrateEmployee(Employee & employeeObject)
{
	cout << employeeObject.getFirstName() << " "
		<< employeeObject.getLastName()
		<< " is a member of the " << employeeObject.getCommunityName() << " community, " << " with member ID " << employeeObject.getMemberId() << endl
		<< "He/She is an employee with Job Title: " << employeeObject.getJobTitle() << ", making "
		<< employeeObject.getYearlySalary() << " per year." << endl;
}

// function that displays the student member data as well as the community member data of the student object.
// The getMemberId function belongs to the student class and overrides the base class member function of the 
// same name.
void demonstrateStudent(Student& studentObj) {
	cout << studentObj.getFirstName() << " "
		<< studentObj.getLastName()
		<< " is a member of the " << studentObj.getCommunityName() << " community, " << " with member ID " << studentObj.getMemberId() << endl
		<< "He/She is of the " << studentObj.getStudentDepartment() << " department with a GPA of: " << fixed << studentObj.getStudentGpa() << endl;
}

// print "SU" for Syracuse University on the console
void printSyracuseBanner() {
	cout
		<< "                   .-----------.            .----.          .----.\n"
		<< "                 /             |            |    |          |    |\n"
		<< "                /    .---------*            |    |          |    |\n"
		<< "               .    /                       |    |          |    |\n"
		<< "               |   |                        |    |          |    |\n"
		<< "               |    .                       |    |          |    |\n"
		<< "                .    *-------.              |    |          |    |\n"
		<< "                 *.            *            |    |          |    |\n"
		<< "                   *----.       *           |    |          |    |\n"
		<< "                          .      *          |    |          |    |\n"
		<< "                          |      |          |    |          |    |\n"
		<< "                         /       /          |    |          |    |\n"
		<< "                .-------*       *           *     *--------*     /\n"
		<< "                |             *              *                  / \n"
		<< "                *----------*                   *--------------*   \n";
}