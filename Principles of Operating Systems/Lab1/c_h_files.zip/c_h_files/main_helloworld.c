/* hello.c - main*/
#include <xinu.h>
/* main - just say hello, then exit */
void main(void)
{
printf("Hello, world!\n");
}
