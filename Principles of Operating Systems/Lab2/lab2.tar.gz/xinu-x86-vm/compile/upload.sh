#!/bin/sh

cp xinu /srv/tftp/xinu.boot
